#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>

// Inisialisasi
LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo myServo;

const int potPin = 34;
const int servoPin = 18;

void setup() {
    Serial.begin(115200);

    // Setup LCD
    lcd.init();
    lcd.backlight();

    // Setup Servo
    ESP32PWM::allocateTimer(0); // Alokasi timer untuk PWM ESP32
    myServo.setPeriodHertz(50); // Standar SG90: 50Hz
    myServo.attach(servoPin, 500, 2400); // Pin, Min pulse, Max pulse

    lcd.setCursor(0, 0);
    lcd.print("SERVO CONTROL");
}

void loop() {
    // 1. Baca Potensio (0 - 4095)
    int adcVal = analogRead(potPin);

    // 2. Mapping ke Sudut Servo (0 - 180 derajat)
    int angle = map(adcVal, 0, 4095, 0, 180);

    // 3. Gerakkan Servo
    myServo.write(angle);

    // 4. Update LCD
    lcd.setCursor(0, 1);
    lcd.print("Sudut: ");
    lcd.print(angle);
    lcd.print((char)223); // Simbol derajat (°)
    lcd.print("   ");     // Clear sisa angka

    // 5. Kirim data ke Serial (Format: ADC,Sudut)
    Serial.print(adcVal);
    Serial.print(",");
    Serial.println(angle);

    delay(20); 
}