#include <Arduino.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Pin
const int potPin = 34;
const int servoPin = 18;

Servo myServo;
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
    Serial.begin(115200);
    
    // Setup LCD
    lcd.init();
    lcd.backlight();
    
    // Setup Servo
    ESP32PWM::allocateTimer(0);
    myServo.setPeriodHertz(50);
    myServo.attach(servoPin, 500, 2400);

    lcd.setCursor(0, 0);
    lcd.print("SERVO MONITOR");
}

void loop() {
    // 1. Baca Potensio (0-4095)
    int rawADC = analogRead(potPin);

    // 2. Map ke Sudut Servo (0-180)
    int angle = map(rawADC, 0, 4095, 0, 180);

    // 3. Gerakkan Servo
    myServo.write(angle);

    // 4. Update LCD
    lcd.setCursor(0, 1);
    lcd.print("Angle: ");
    lcd.print(angle);
    lcd.print((char)223); // Simbol derajat
    lcd.print("    ");

    // 5. Kirim data ke Python untuk Grafik
    // Format: rawADC,angle
    Serial.print(rawADC);
    Serial.print(",");
    Serial.println(angle);

    delay(20); 
}