import customtkinter as ctk
import serial
import threading
import time
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import deque

# --- CONFIG ---
SERIAL_PORT = "COM5" 
BAUD_RATE = 115200

class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Data Monitoring: Potentiometer & Servo")
        self.geometry("900x600")

        # Data Storage
        self.data_adc = deque([0]*100, maxlen=100)
        self.data_angle = deque([0]*100, maxlen=100)
        self.is_running = True

        # Setup GUI
        self.create_widgets()
        
        # Start Serial Thread
        try:
            self.ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
            threading.Thread(target=self.read_serial, daemon=True).start()
            self.update_plot()
        except:
            print(f"Gagal koneksi ke {SERIAL_PORT}. Pastikan port benar dan Serial Monitor tertutup.")

    def create_widgets(self):
        # Frame Grafik
        self.plot_frame = ctk.CTkFrame(self)
        self.plot_frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Matplotlib Figure
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(6, 5))
        self.fig.patch.set_facecolor('#2b2b2b')
        self.fig.tight_layout(pad=3.0)

        # Plot ADC
        self.ax1.set_facecolor('#1e1e1e')
        self.ax1.set_title("Potentiometer (ADC 0-4095)", color='white')
        self.ax1.set_ylim(-100, 4200)
        self.line_adc, = self.ax1.plot([], [], color='cyan')
        self.ax1.tick_params(colors='white')
        self.ax1.grid(True, color='#444444')

        # Plot Angle
        self.ax2.set_facecolor('#1e1e1e')
        self.ax2.set_title("Servo Angle (0-180°)", color='white')
        self.ax2.set_ylim(-10, 190)
        self.line_angle, = self.ax2.plot([], [], color='orange')
        self.ax2.tick_params(colors='white')
        self.ax2.grid(True, color='#444444')

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def read_serial(self):
        while self.is_running:
            if self.ser.is_open:
                line = self.ser.readline().decode('utf-8').strip()
                if line:
                    try:
                        parts = line.split(',')
                        if len(parts) == 2:
                            self.data_adc.append(int(parts[0]))
                            self.data_angle.append(int(parts[1]))
                    except:
                        pass
            time.sleep(0.01)

    def update_plot(self):
        self.line_adc.set_data(range(len(self.data_adc)), list(self.data_adc))
        self.ax1.set_xlim(0, 100)
        
        self.line_angle.set_data(range(len(self.data_angle)), list(self.data_angle))
        self.ax2.set_xlim(0, 100)
        
        self.canvas.draw_idle()
        self.after(50, self.update_plot)

if __name__ == "__main__":
    app = App()
    app.mainloop()