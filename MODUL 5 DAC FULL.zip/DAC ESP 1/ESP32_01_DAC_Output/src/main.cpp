#include <Arduino.h>

// Pin DAC pada ESP32 hanya ada di GPIO 25 dan 26
const int dacPin = 25; 

void setup() {
  Serial.begin(115200);
  Serial.println("Praktikum DAC - Kontrol Kecerahan LED");
}

void loop() {
  // Efek Breathing (Redup ke Terang)
  for (int value = 0; value <= 255; value++) {
    dacWrite(dacPin, value); // Mengeluarkan tegangan analog asli
    delay(10);
  }

  // Efek Breathing (Terang ke Redup)
  for (int value = 255; value >= 0; value--) {
    dacWrite(dacPin, value);
    delay(10);
  }
}