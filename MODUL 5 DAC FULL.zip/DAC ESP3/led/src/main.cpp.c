#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Konfigurasi PWM
const int ledPin = 19;     // Pin LED
const int potPin = 34;     // Pin Potensio
const int freq = 5000;     // Frekuensi 5kHz
const int ledChannel = 0;  // Channel PWM (0-15)
const int resolution = 10; // Resolusi 10-bit (0-1023)

LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
    Serial.begin(115200);

    // Inisialisasi LCD
    lcd.init();
    lcd.backlight();

    // Inisialisasi PWM ESP32
    ledcSetup(ledChannel, freq, resolution);
    ledcAttachPin(ledPin, ledChannel);

    lcd.setCursor(0, 0);
    lcd.print("LED PWM MODE");
}

void loop() {
    // 1. Baca Potensio (0-4095)
    int adcVal = analogRead(potPin);

    // 2. Map ke resolusi PWM (10-bit: 0-1023)
    int pwmVal = map(adcVal, 0, 4095, 0, 1023);

    // 3. Output PWM ke LED
    ledcWrite(ledChannel, pwmVal);

    // 4. Hitung Persen Kecerahan
    int percent = map(pwmVal, 0, 1023, 0, 100);

    // 5. Update LCD
    lcd.setCursor(0, 1);
    lcd.print("Duty: ");
    lcd.print(pwmVal);
    lcd.print(" (");
    lcd.print(percent);
    lcd.print("%)  ");

    // 6. Data untuk GUI Python
    Serial.print(adcVal);
    Serial.print(",");
    Serial.println(pwmVal);

    delay(30);
}