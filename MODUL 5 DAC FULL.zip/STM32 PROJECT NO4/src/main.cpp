#include <Arduino.h>
#include <Servo.h>

Servo myServo;
#define SERVO_PIN PA0
#define POT_PIN   PA1
#define LED_PIN   PA4

void setup() {
    Serial.begin(115200);
    delay(2000);
    Serial.println("Program Gabungan: Servo & LED Dimmer\n");

    myServo.attach(SERVO_PIN);
    
    // Set resolusi ADC ke 12-bit (0-4095) agar pembacaan potensio halus
    analogReadResolution(12);
    
    // Set resolusi PWM ke 12-bit agar transisi LED sangat halus
    analogWriteResolution(12);
    
    pinMode(LED_PIN, OUTPUT);
}

void loop() {
    // 1. Baca nilai potensiometer (0 - 4095)
    int potValue = analogRead(POT_PIN);

    // 2. Map untuk Servo (0 - 180 derajat)
    int servoAngle = map(potValue, 0, 4095, 0, 180);
    myServo.write(servoAngle);

    // 3. Map untuk LED (0 - 4095)
    // Karena resolusi PWM kita set 12-bit, range-nya sama dengan ADC
    int ledBrightness = potValue; 
    analogWrite(LED_PIN, ledBrightness);

    // 4. Monitoring di Serial
    Serial.printf("Pot: %d | Angle: %d | LED: %d\n", potValue, servoAngle, ledBrightness);

    delay(20); // Delay kecil agar gerakan servo smooth (halus)
}